import React, { useState } from 'react';
import { PhotoBooth } from './views/PhotoBooth';
import { Analyzer } from './views/Analyzer';
import { MagicEditor } from './views/MagicEditor';
import { AvatarEnvironment } from './views/AvatarEnvironment';
import { LiveStudio } from './views/LiveStudio';
import { AppMode } from './types';
import { Camera, Scan, Wand2, History, MonitorPlay, Aperture } from 'lucide-react';

const App: React.FC = () => {
  const [mode, setMode] = useState<AppMode>(AppMode.LIVE_STUDIO);

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-200">
      {/* Navbar */}
      <nav className="border-b border-slate-800 bg-[#0f172a]/80 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-2 rounded-lg">
                <History className="text-white w-5 h-5" />
              </div>
              <span className="font-bold text-xl tracking-tight text-white hidden md:block">Anti-Gravity</span>
            </div>
            <div className="flex space-x-1 overflow-x-auto no-scrollbar">
               <NavButton 
                 active={mode === AppMode.LIVE_STUDIO} 
                 onClick={() => setMode(AppMode.LIVE_STUDIO)}
                 icon={<Aperture size={18}/>}
                 label="Sandra YouTuber"
               />
               <NavButton 
                 active={mode === AppMode.AVATAR_ENV} 
                 onClick={() => setMode(AppMode.AVATAR_ENV)}
                 icon={<MonitorPlay size={18}/>}
                 label="Estudio TV"
               />
               <NavButton 
                 active={mode === AppMode.PHOTO_BOOTH} 
                 onClick={() => setMode(AppMode.PHOTO_BOOTH)}
                 icon={<Camera size={18}/>}
                 label="Fotos"
               />
               <NavButton 
                 active={mode === AppMode.MAGIC_EDITOR} 
                 onClick={() => setMode(AppMode.MAGIC_EDITOR)}
                 icon={<Wand2 size={18}/>}
                 label="Editor Mágico"
               />
               <NavButton 
                 active={mode === AppMode.ANALYZER} 
                 onClick={() => setMode(AppMode.ANALYZER)}
                 icon={<Scan size={18}/>}
                 label="Analizar"
               />
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
        {mode === AppMode.LIVE_STUDIO && <LiveStudio />}
        {mode === AppMode.PHOTO_BOOTH && <PhotoBooth />}
        {mode === AppMode.MAGIC_EDITOR && <MagicEditor />}
        {mode === AppMode.ANALYZER && <Analyzer />}
        {mode === AppMode.AVATAR_ENV && <AvatarEnvironment />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 mt-12 py-8 text-center text-slate-500 text-sm">
        <p>Powered by Gemini 3.0 Pro, Gemini 2.5 Flash & Veo</p>
      </footer>
    </div>
  );
};

const NavButton: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
      active 
      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/25' 
      : 'text-slate-400 hover:text-white hover:bg-slate-800'
    }`}
  >
    {icon}
    <span className="hidden sm:inline">{label}</span>
    <span className="sm:hidden">{label.split(' ')[0]}</span>
  </button>
);

export default App;