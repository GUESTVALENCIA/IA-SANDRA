import React, { useRef, useState, useEffect } from 'react';
import { Camera, RefreshCw, X } from 'lucide-react';
import { Button } from './Button';

interface CameraCaptureProps {
  onCapture: (file: File) => void;
  onClose: () => void;
}

export const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const startCamera = async () => {
    setError('');
    
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setError("Camera API not available in this browser. Please use HTTPS.");
      return;
    }

    // Comprehensive Fallback Strategy for Static Capture (Video only)
    const attempts = [
      // 1. Ideal (HD, User)
      { video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } } },
      // 2. Basic User
      { video: { facingMode: 'user' } },
      // 3. Environment (Rear Camera)
      { video: { facingMode: 'environment' } },
      // 4. Any Video Device
      { video: true }
    ];
    
    for (const constraints of attempts) {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
        
        if (mediaStream) {
          setStream(mediaStream);
          if (videoRef.current) {
            videoRef.current.srcObject = mediaStream;
            await videoRef.current.play();
          }
          return; // Success
        }
      } catch (err) {
        console.warn("Camera attempt failed:", constraints, err);
      }
    }

    // If we get here, all attempts failed
    setError("Could not access camera. Please ensure permissions are granted and a camera is available.");
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const context = canvas.getContext('2d');
      if (context) {
        // Mirror the image to match the video feed preview
        context.translate(canvas.width, 0);
        context.scale(-1, 1);
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], "camera-capture.jpg", { type: "image/jpeg" });
            onCapture(file);
            stopCamera();
          }
        }, 'image/jpeg', 0.95);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4">
      <div className="relative w-full max-w-3xl bg-slate-800 rounded-2xl overflow-hidden shadow-2xl border border-slate-700">
        <div className="flex justify-between items-center p-4 bg-slate-900 border-b border-slate-700">
          <h3 className="text-lg font-semibold text-white">Take a Selfie</h3>
          <button onClick={() => { stopCamera(); onClose(); }} className="text-slate-400 hover:text-white">
            <X size={24} />
          </button>
        </div>
        
        <div className="relative bg-black aspect-video flex items-center justify-center overflow-hidden">
          {error ? (
            <div className="text-red-400 text-center p-4">
              <p>{error}</p>
              <Button variant="secondary" onClick={startCamera} className="mt-4" icon={<RefreshCw size={16}/>}>Retry</Button>
            </div>
          ) : (
            <video 
              ref={videoRef} 
              autoPlay 
              playsInline 
              className="w-full h-full object-cover transform -scale-x-100"
            />
          )}
          <canvas ref={canvasRef} className="hidden" />
        </div>

        <div className="p-6 bg-slate-900 flex justify-center gap-4">
          <Button variant="secondary" onClick={() => { stopCamera(); onClose(); }}>Cancel</Button>
          <Button 
            variant="primary" 
            onClick={handleCapture} 
            disabled={!!error}
            icon={<Camera size={20} />}
            className="w-full max-w-xs py-3 text-lg"
          >
            Snap Photo
          </Button>
        </div>
      </div>
    </div>
  );
};