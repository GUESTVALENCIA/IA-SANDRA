import React, { useRef } from 'react';
import { Upload, Camera } from 'lucide-react';
import { Button } from './Button';

interface ImageUploaderProps {
  onFileSelect: (file: File) => void;
  onCameraClick: () => void;
  currentImage?: File | null;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onFileSelect, onCameraClick, currentImage }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onFileSelect(e.target.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onFileSelect(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="w-full">
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileChange} 
        accept="image/*" 
        className="hidden" 
      />
      
      {!currentImage ? (
        <div 
          className="border-2 border-dashed border-slate-600 rounded-xl p-8 md:p-12 flex flex-col items-center justify-center text-center hover:bg-slate-800/50 hover:border-indigo-500 transition-all cursor-pointer group"
          onClick={() => fileInputRef.current?.click()}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          <div className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <Upload className="text-slate-300 w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-white mb-2">Upload an Image</h3>
          <p className="text-slate-400 mb-6">Drag & drop or click to select</p>
          
          <div className="flex items-center gap-3 w-full max-w-xs">
             <div className="h-px bg-slate-700 flex-1"></div>
             <span className="text-slate-500 text-sm font-medium uppercase">Or</span>
             <div className="h-px bg-slate-700 flex-1"></div>
          </div>

          <Button 
            variant="primary" 
            className="mt-6 w-full max-w-xs"
            onClick={(e) => { e.stopPropagation(); onCameraClick(); }}
            icon={<Camera size={18} />}
          >
            Use Camera
          </Button>
        </div>
      ) : (
        <div className="relative rounded-xl overflow-hidden border border-slate-700 shadow-xl group">
          <img 
            src={URL.createObjectURL(currentImage)} 
            alt="Preview" 
            className="w-full h-64 md:h-96 object-cover" 
          />
          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4 backdrop-blur-sm">
             <Button variant="secondary" onClick={() => fileInputRef.current?.click()}>
                Change Image
             </Button>
             <Button variant="primary" onClick={onCameraClick} icon={<Camera size={18}/>}>
                Retake
             </Button>
          </div>
        </div>
      )}
    </div>
  );
};