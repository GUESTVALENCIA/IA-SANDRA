export enum AppMode {
  PHOTO_BOOTH = 'PHOTO_BOOTH',
  ANALYZER = 'ANALYZER',
  MAGIC_EDITOR = 'MAGIC_EDITOR',
  AVATAR_ENV = 'AVATAR_ENV',
  LIVE_STUDIO = 'LIVE_STUDIO'
}

export interface GeneratedImage {
  url: string;
  prompt: string;
  timestamp: number;
}

export interface AnalysisResult {
  text: string;
  timestamp: number;
}

export interface HistoryItem {
  type: 'image' | 'analysis';
  content: GeneratedImage | AnalysisResult;
}

export interface AgentCommand {
  action: 'CAPTURE_PHOTO' | 'RECORD_VIDEO' | 'GENERATE_AVATAR' | 'GENERATE_ENV' | 'UNKNOWN';
  parameters?: {
    duration?: number; // for video
    prompt?: string; // for generation
  };
  responseToUser?: string;
}

export const ERAS = [
  { id: '1920s', label: 'Roaring 20s', prompt: 'Transform the scene into a 1920s jazz age setting, wearing flapper or gangster style clothing, sepia tone, vintage photography style.' },
  { id: 'cyberpunk', label: 'Cyberpunk 2077', prompt: 'Transform the scene into a futuristic cyberpunk city with neon lights, cybernetic enhancements on the person, high tech fashion.' },
  { id: 'victorian', label: 'Victorian Era', prompt: 'Transform the scene into 19th century Victorian London, wearing formal Victorian attire, misty cobblestone streets.' },
  { id: 'egypt', label: 'Ancient Egypt', prompt: 'Transform the scene into Ancient Egypt, with pyramids in background, wearing gold and linen pharaoh style clothing.' },
  { id: 'medieval', label: 'Medieval Knight', prompt: 'Transform the scene into a medieval castle courtyard, wearing shining silver plate armor, epic fantasy lighting.' },
  { id: 'space', label: 'Deep Space', prompt: 'Transform the background into a sci-fi spaceship interior, looking out at a nebula, wearing a sleek space suit.' },
];