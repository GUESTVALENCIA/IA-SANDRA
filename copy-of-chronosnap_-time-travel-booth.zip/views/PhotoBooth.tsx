import React, { useState } from 'react';
import { ImageUploader } from '../components/ImageUploader';
import { CameraCapture } from '../components/CameraCapture';
import { Button } from '../components/Button';
import { editImage } from '../services/geminiService';
import { ERAS } from '../types';
import { Wand2, Download, RotateCcw } from 'lucide-react';

export const PhotoBooth: React.FC = () => {
  const [sourceImage, setSourceImage] = useState<File | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedEra, setSelectedEra] = useState<string | null>(null);
  const [customPrompt, setCustomPrompt] = useState("");
  const [isCustomMode, setIsCustomMode] = useState(false);

  const handleGenerate = async () => {
    if (!sourceImage) return;
    
    let promptToUse = customPrompt;
    if (!isCustomMode && selectedEra) {
       const era = ERAS.find(e => e.id === selectedEra);
       if (era) promptToUse = era.prompt;
    }

    if (!promptToUse) return;

    // Enhance prompt for better results with Gemini Flash Image
    const enhancedPrompt = `${promptToUse}. Keep the person's face and identity exactly the same, only change the style, clothing, and background. High quality, photorealistic.`;

    setIsLoading(true);
    try {
      const resultImage = await editImage(sourceImage, enhancedPrompt);
      setGeneratedImage(resultImage);
    } catch (error) {
      alert("Failed to generate image. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const reset = () => {
    setGeneratedImage(null);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {isCameraOpen && (
        <CameraCapture 
          onCapture={(file) => { setSourceImage(file); setIsCameraOpen(false); setGeneratedImage(null); }} 
          onClose={() => setIsCameraOpen(false)} 
        />
      )}

      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400">
          Time Travel Photo Booth
        </h2>
        <p className="text-slate-400">
          Upload a selfie and transport yourself to another era using Gemini 2.5 Flash.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        
        {/* Left Column: Input */}
        <div className="space-y-6 bg-slate-800/50 p-6 rounded-2xl border border-slate-700">
          <ImageUploader 
            currentImage={sourceImage}
            onFileSelect={(f) => { setSourceImage(f); setGeneratedImage(null); }}
            onCameraClick={() => setIsCameraOpen(true)}
          />

          {sourceImage && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center justify-between">
                 <h3 className="text-lg font-semibold text-white">Choose Destination</h3>
                 <button 
                   onClick={() => setIsCustomMode(!isCustomMode)}
                   className="text-xs text-indigo-400 hover:text-indigo-300 underline"
                 >
                   {isCustomMode ? "Back to Presets" : "Use Custom Prompt"}
                 </button>
              </div>

              {!isCustomMode ? (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {ERAS.map((era) => (
                    <button
                      key={era.id}
                      onClick={() => setSelectedEra(era.id)}
                      className={`p-3 rounded-xl border text-sm font-medium transition-all ${
                        selectedEra === era.id 
                        ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-900/50' 
                        : 'bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600 hover:border-slate-500'
                      }`}
                    >
                      {era.label}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="space-y-2">
                  <textarea
                    value={customPrompt}
                    onChange={(e) => setCustomPrompt(e.target.value)}
                    placeholder="Describe where you want to go... (e.g., 'A futuristic mars colony')"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-4 text-white placeholder-slate-500 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none resize-none h-32"
                  />
                  <p className="text-xs text-slate-500">
                    Tip: Be specific about lighting, clothing, and background.
                  </p>
                </div>
              )}

              <Button 
                className="w-full py-4 text-lg mt-4" 
                onClick={handleGenerate}
                disabled={(!selectedEra && !customPrompt) || isLoading}
                isLoading={isLoading}
                icon={<Wand2 size={20} />}
              >
                {isLoading ? "Traveling Through Time..." : "Generate Photo"}
              </Button>
            </div>
          )}
        </div>

        {/* Right Column: Output */}
        <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700 min-h-[400px] flex flex-col items-center justify-center relative overflow-hidden">
          {generatedImage ? (
             <div className="w-full h-full flex flex-col items-center space-y-4 animate-fade-in">
                <div className="relative group w-full rounded-xl overflow-hidden shadow-2xl border border-indigo-500/30">
                  <img 
                    src={generatedImage} 
                    alt="Time Travel Result" 
                    className="w-full h-auto object-cover" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center p-6">
                    <a 
                      href={generatedImage} 
                      download="chrono-snap-result.png"
                      className="bg-white text-indigo-900 px-6 py-2 rounded-full font-bold flex items-center gap-2 hover:bg-indigo-50 transition-colors"
                    >
                      <Download size={18} /> Save Image
                    </a>
                  </div>
                </div>
                <div className="flex gap-4">
                  <Button variant="ghost" onClick={reset} icon={<RotateCcw size={16} />}>
                     Try Another Era
                  </Button>
                </div>
             </div>
          ) : (
             <div className="text-center text-slate-500 space-y-4">
                {isLoading ? (
                  <div className="flex flex-col items-center gap-4">
                     <div className="relative w-24 h-24">
                        <div className="absolute inset-0 border-4 border-indigo-500/30 rounded-full animate-ping"></div>
                        <div className="absolute inset-2 border-4 border-indigo-500 rounded-full animate-spin border-t-transparent"></div>
                     </div>
                     <p className="animate-pulse">Gemini is rewriting history...</p>
                  </div>
                ) : (
                  <>
                    <div className="w-20 h-20 bg-slate-700/50 rounded-full flex items-center justify-center mx-auto mb-2">
                       <Wand2 className="w-10 h-10 text-slate-600" />
                    </div>
                    <p>Your time travel photo will appear here.</p>
                  </>
                )}
             </div>
          )}
        </div>
      </div>
    </div>
  );
};