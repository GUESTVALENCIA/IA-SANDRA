import React, { useState } from 'react';
import { Button } from '../components/Button';
import { generateEnvironmentImage, generateEnvironmentVideo } from '../services/geminiService';
import { MonitorPlay, Image as ImageIcon, Zap, Film, Download } from 'lucide-react';

export const AvatarEnvironment: React.FC = () => {
  const [prompt, setPrompt] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [resultType, setResultType] = useState<'image' | 'video' | null>(null);
  const [mode, setMode] = useState<'image' | 'video'>('image');

  const handleGenerate = async () => {
    if (!prompt) return;
    setIsLoading(true);
    setResultUrl(null);
    setResultType(null);

    try {
      if (mode === 'image') {
        // Use Gemini 2.5 Flash Image (Nano Banana)
        const url = await generateEnvironmentImage(prompt + ". Photorealistic, high quality background, wide shot, cinematic lighting.");
        setResultUrl(url);
        setResultType('image');
      } else {
        // Use Veo 3.1
        const url = await generateEnvironmentVideo(prompt + ". Cinematic, atmospheric, background loop, stable camera.");
        setResultUrl(url);
        setResultType('video');
      }
    } catch (error) {
      alert(`Failed to generate ${mode}. Please try again.`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <h2 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-300 to-orange-500">
          Avatar Environment Generator
        </h2>
        <p className="text-slate-400 max-w-2xl mx-auto">
          This module simulates the "Anti-Gravity" backend. It generates the scene where your AI Avatar will "live".
          Use <span className="text-white font-semibold">Flash Image</span> for instant backgrounds or <span className="text-white font-semibold">Veo</span> for moving video sets.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Controls */}
        <div className="lg:col-span-1 space-y-6 bg-slate-800/50 p-6 rounded-2xl border border-slate-700 h-fit">
          
          <div className="flex gap-2 p-1 bg-slate-900/80 rounded-lg">
             <button
               onClick={() => setMode('image')}
               className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-md text-sm font-medium transition-all ${mode === 'image' ? 'bg-slate-700 text-white shadow' : 'text-slate-500 hover:text-slate-300'}`}
             >
               <ImageIcon size={16} /> Static (Fast)
             </button>
             <button
               onClick={() => setMode('video')}
               className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-md text-sm font-medium transition-all ${mode === 'video' ? 'bg-slate-700 text-white shadow' : 'text-slate-500 hover:text-slate-300'}`}
             >
               <Film size={16} /> Video (Veo)
             </button>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Voice Command Simulation</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={mode === 'image' ? "E.g., 'A cozy coffee shop in Paris, raining outside'" : "E.g., 'A neon hologram of a city, slowly rotating'"}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl p-4 text-white placeholder-slate-500 focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none resize-none h-40"
            />
          </div>

          <Button 
            className={`w-full py-4 text-lg ${mode === 'image' ? 'bg-orange-600 hover:bg-orange-700' : 'bg-blue-600 hover:bg-blue-700'}`}
            onClick={handleGenerate}
            disabled={!prompt || isLoading}
            isLoading={isLoading}
            icon={mode === 'image' ? <Zap size={20} /> : <MonitorPlay size={20} />}
          >
            {isLoading ? "Generating Environment..." : `Generate ${mode === 'image' ? 'Background' : 'Video'}`}
          </Button>
          
          <div className="text-xs text-slate-500 p-3 bg-slate-900/50 rounded-lg border border-slate-800">
             <p className="font-semibold mb-1">System Note:</p>
             In your production app, the output URL from this generator would be passed to the frontend layer behind the HeyGen iframe/video stream.
          </div>
        </div>

        {/* Preview Stage */}
        <div className="lg:col-span-2 bg-black rounded-2xl border border-slate-800 overflow-hidden relative flex flex-col min-h-[500px]">
           
           {/* Header Overlay */}
           <div className="absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/80 to-transparent z-10 flex justify-between items-start">
              <div className="flex items-center gap-2">
                 <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                 <span className="text-white/80 text-xs font-mono uppercase tracking-widest">Live Environment</span>
              </div>
              {resultUrl && (
                 <a href={resultUrl} download={`env-${Date.now()}.${resultType === 'image' ? 'png' : 'mp4'}`} className="text-white/60 hover:text-white">
                    <Download size={20} />
                 </a>
              )}
           </div>

           {/* Content */}
           <div className="flex-1 flex items-center justify-center">
              {isLoading ? (
                 <div className="text-center space-y-4">
                    <div className="w-16 h-16 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
                    <p className="text-orange-400 animate-pulse">Creating world...</p>
                 </div>
              ) : resultUrl ? (
                 resultType === 'image' ? (
                    <img src={resultUrl} alt="Generated Environment" className="w-full h-full object-cover" />
                 ) : (
                    <video src={resultUrl} autoPlay loop muted playsInline className="w-full h-full object-cover" />
                 )
              ) : (
                 <div className="text-center text-slate-600">
                    <MonitorPlay size={64} strokeWidth={1} className="mx-auto mb-4 opacity-50" />
                    <p className="text-lg">Environment Offline</p>
                    <p className="text-sm">Generate a scene to activate the stage</p>
                 </div>
              )}
           </div>

           {/* Mock Avatar Overlay (Visual Aid) */}
           {resultUrl && (
             <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 h-4/5 w-auto aspect-[1/2] flex items-end justify-center pointer-events-none">
                <div className="w-64 h-full bg-gradient-to-t from-black/80 via-slate-900/20 to-transparent border-2 border-dashed border-white/20 rounded-t-full flex items-center justify-center text-white/50 backdrop-blur-[1px]">
                   <span className="font-mono text-xs bg-black/50 px-2 py-1 rounded">Avatar Layer (HeyGen)</span>
                </div>
             </div>
           )}
        </div>

      </div>
    </div>
  );
};