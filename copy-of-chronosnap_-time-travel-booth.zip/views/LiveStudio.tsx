import React, { useRef, useState, useEffect } from 'react';
import { Button } from '../components/Button';
import { parseAgentCommand, generateEnvironmentImage, generateEnvironmentVideo, editImage } from '../services/geminiService';
import { AgentCommand } from '../types';
import { Mic, Send, Aperture, Video, User, MonitorPlay, Sparkles, AlertCircle, RefreshCw, MicOff } from 'lucide-react';

export const LiveStudio: React.FC = () => {
  // --- State ---
  const [messages, setMessages] = useState<{role: 'user' | 'ai', text: string}[]>([
    { role: 'ai', text: "¡Hola Sandrita! Soy Sandra YouTuber. 🎬✨ ¿Qué vamos a crear hoy para tu canal? Pídeme 'Hacer una foto', 'Grabar un video', 'Crear mi avatar 3D' o 'Viajar a la luna'."}
  ]);
  const [inputText, setInputText] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [usingAudio, setUsingAudio] = useState(true);
  
  // --- Assets State ---
  const [capturedMedia, setCapturedMedia] = useState<{ type: 'image' | 'video', url: string, file?: File } | null>(null);
  const [generatedAvatar, setGeneratedAvatar] = useState<string | null>(null);
  const [environmentUrl, setEnvironmentUrl] = useState<string | null>(null);
  const [environmentType, setEnvironmentType] = useState<'image' | 'video' | null>(null);

  // --- Refs ---
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // --- Camera Setup ---
  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const startCamera = async () => {
    setCameraError(null);
    setUsingAudio(true);

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError("No se detecta cámara. Por favor usa HTTPS o localhost.");
        return;
    }

    // Comprehensive Fallback Strategy
    // Many "Device not found" errors occur because audio is requested but no mic is present.
    const attempts = [
      // 1. Ideal: HD, User-facing, Audio enabled
      { 
        constraints: { video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } }, audio: true },
        hasAudio: true
      },
      // 2. Fallback: HD, User-facing, NO Audio (Fixes desktop without mic)
      { 
        constraints: { video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false },
        hasAudio: false
      },
      // 3. Fallback: Basic Resolution, Audio enabled
      { 
        constraints: { video: true, audio: true },
        hasAudio: true
      },
      // 4. Fallback: Basic Resolution, NO Audio
      { 
        constraints: { video: true, audio: false },
        hasAudio: false
      },
      // 5. Fallback: Environment (Back camera), NO Audio
      {
        constraints: { video: { facingMode: 'environment' }, audio: false },
        hasAudio: false
      }
    ];

    for (const attempt of attempts) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia(attempt.constraints);
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }

        setUsingAudio(attempt.hasAudio);
        
        if (!attempt.hasAudio) {
             console.warn("Cámara iniciada sin audio (modo fallback).");
        }
        
        return; // Success
      } catch (err) {
        console.warn(`Intento de cámara fallido:`, attempt.constraints, err);
      }
    }

    setCameraError("No se pudo iniciar la cámara. Revisa los permisos.");
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(t => t.stop());
      videoRef.current.srcObject = null;
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // --- Core Agent Logic ---
  const handleCommand = async () => {
    if (!inputText.trim()) return;
    
    const userMsg = inputText;
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInputText("");
    setIsProcessing(true);

    try {
      // 1. Brain: Interpret Intent
      const command = await parseAgentCommand(userMsg);
      setMessages(prev => [...prev, { role: 'ai', text: command.responseToUser || "¡En marcha!" }]);

      // 2. Body: Execute Hardware/GenAI Actions
      await executeCommand(command);

    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { role: 'ai', text: "Tuve un problemilla técnico, ¿probamos otra vez?" }]);
    } finally {
      setIsProcessing(false);
    }
  };

  const executeCommand = async (command: AgentCommand) => {
    switch (command.action) {
      case 'CAPTURE_PHOTO':
        capturePhoto();
        break;

      case 'RECORD_VIDEO':
        const duration = command.parameters?.duration || 5;
        recordVideo(duration);
        break;

      case 'GENERATE_AVATAR':
        if (!capturedMedia || capturedMedia.type !== 'image' || !capturedMedia.file) {
          setMessages(prev => [...prev, { role: 'ai', text: "¡Necesito una foto tuya primero! Pídeme 'Hacer una foto'." }]);
          return;
        }
        await generateAvatar(capturedMedia.file);
        break;

      case 'GENERATE_ENV':
        if (!command.parameters?.prompt) return;
        await createEnvironment(command.parameters.prompt);
        break;
    }
  };

  // --- Hardware Actions ---

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    
    if (video.readyState !== 4) {
        setMessages(prev => [...prev, { role: 'ai', text: "La cámara se está preparando..." }]);
        return;
    }

    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (ctx) {
        ctx.translate(canvas.width, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(video, 0, 0);
        canvas.toBlob(blob => {
            if (blob) {
                const file = new File([blob], "selfie.jpg", { type: 'image/jpeg' });
                const url = URL.createObjectURL(blob);
                setCapturedMedia({ type: 'image', url, file });
            }
        }, 'image/jpeg', 0.95);
    }
  };

  const recordVideo = (seconds: number) => {
    if (!videoRef.current || !videoRef.current.srcObject) {
        setMessages(prev => [...prev, { role: 'ai', text: "Cámara no lista." }]);
        return;
    }
    
    setIsRecording(true);
    const stream = videoRef.current.srcObject as MediaStream;
    
    try {
        const recorder = new MediaRecorder(stream);
        mediaRecorderRef.current = recorder;
        chunksRef.current = [];
    
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) chunksRef.current.push(e.data);
        };
    
        recorder.onstop = () => {
          const blob = new Blob(chunksRef.current, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          setCapturedMedia({ type: 'video', url });
          setIsRecording(false);
        };
    
        recorder.start();
        setMessages(prev => [...prev, { role: 'ai', text: `¡Grabando acción por ${seconds} segundos! 🎥` }]);
        
        setTimeout(() => {
          if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
            mediaRecorderRef.current.stop();
          }
        }, seconds * 1000);
    } catch (e) {
        console.error(e);
        setIsRecording(false);
        setMessages(prev => [...prev, { role: 'ai', text: "No pude grabar el video. Intenta con una foto." }]);
    }
  };

  // --- GenAI Actions ---

  const generateAvatar = async (file: File) => {
    setMessages(prev => [...prev, { role: 'ai', text: "✨ ¡Magia! Convirtiéndote en personaje animado 3D..." }]);
    try {
      // Kid-friendly, high quality avatar prompt
      const avatarUrl = await editImage(file, "Transform this person into a cute, high-quality 3D Pixar-style animated character, friendly expression, vibrant colors, 8k resolution, detailed.");
      setGeneratedAvatar(avatarUrl);
      setMessages(prev => [...prev, { role: 'ai', text: "¡Avatar creado! Ahora podemos ponerle un fondo mágico." }]);
    } catch (e) {
      console.error(e);
      setMessages(prev => [...prev, { role: 'ai', text: "Uy, la magia falló esta vez." }]);
    }
  };

  const createEnvironment = async (prompt: string) => {
    setMessages(prev => [...prev, { role: 'ai', text: `🎨 Pintando mundo mágico: ${prompt}...` }]);
    try {
        const isVideoRequest = prompt.toLowerCase().includes('video') || prompt.toLowerCase().includes('movimiento') || prompt.toLowerCase().includes('animado');
        
        if (isVideoRequest) {
            const url = await generateEnvironmentVideo("Magical fantasy world for kids, " + prompt + ", cinematic, colorful, 4k.");
            setEnvironmentUrl(url);
            setEnvironmentType('video');
        } else {
            const url = await generateEnvironmentImage("Magical fantasy background for kids video, " + prompt + ", colorful, hyperrealistic 8k.");
            setEnvironmentUrl(url);
            setEnvironmentType('image');
        }
        setMessages(prev => [...prev, { role: 'ai', text: "¡Escenario listo para la acción!" }]);
    } catch (e) {
        setMessages(prev => [...prev, { role: 'ai', text: "No pude crear ese mundo." }]);
    }
  };

  return (
    <div className="h-[calc(100vh-6rem)] flex flex-col lg:flex-row gap-6 overflow-hidden">
      
      {/* Left Column: The Stage */}
      <div className="flex-1 flex flex-col gap-4 min-h-0">
        <div className="relative flex-1 bg-black rounded-2xl overflow-hidden shadow-2xl border border-slate-700 group">
           
           {/* Base Layer: Environment */}
           {environmentUrl ? (
               environmentType === 'image' ? (
                   <img src={environmentUrl} className="absolute inset-0 w-full h-full object-cover z-0" alt="env" />
               ) : (
                   <video src={environmentUrl} autoPlay loop muted playsInline className="absolute inset-0 w-full h-full object-cover z-0" />
               )
           ) : (
               <div className="absolute inset-0 bg-gradient-to-br from-slate-900 to-black z-0" />
           )}

           {/* Middle Layer: Avatar or Live Camera */}
           {generatedAvatar ? (
               <div className="absolute inset-0 z-10 flex items-end justify-center pointer-events-none">
                   <img src={generatedAvatar} className="h-5/6 w-auto object-contain mix-blend-normal" alt="avatar" style={{ filter: 'drop-shadow(0 0 20px rgba(255,255,255,0.3))' }} />
               </div>
           ) : (
              capturedMedia ? (
                  capturedMedia.type === 'image' ? (
                    <img src={capturedMedia.url} className="absolute inset-0 w-full h-full object-contain z-10" alt="captured" />
                  ) : (
                    <video src={capturedMedia.url} controls className="absolute inset-0 w-full h-full object-contain z-10" />
                  )
              ) : (
                <>
                  <video ref={videoRef} autoPlay playsInline muted className="absolute inset-0 w-full h-full object-cover transform -scale-x-100 z-10 opacity-90 hover:opacity-100 transition-opacity" />
                  {!usingAudio && !cameraError && (
                     <div className="absolute top-4 left-4 z-20 bg-black/50 text-white text-xs px-3 py-1 rounded-full flex items-center gap-2 pointer-events-none">
                       <MicOff size={12} className="text-red-400" />
                       <span>Modo Sin Audio</span>
                     </div>
                  )}
                  
                  {cameraError && (
                    <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-slate-900/90 p-6 text-center animate-fade-in">
                        <div className="p-4 bg-red-500/10 rounded-full mb-4 border border-red-500/30">
                            <AlertCircle className="w-10 h-10 text-red-400" />
                        </div>
                        <h3 className="text-xl font-semibold text-white mb-2">Error de Cámara</h3>
                        <p className="text-slate-400 mb-6 max-w-md">{cameraError}</p>
                        <Button variant="secondary" onClick={startCamera} icon={<RefreshCw size={18} />}>
                            Reintentar
                        </Button>
                    </div>
                  )}
                </>
              )
           )}

           {/* Overlays */}
           {isRecording && (
               <div className="absolute top-6 left-6 z-50 flex items-center gap-2 bg-red-500/20 backdrop-blur-md px-4 py-2 rounded-full border border-red-500">
                   <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                   <span className="text-red-100 font-mono font-bold">GRABANDO</span>
               </div>
           )}

           <canvas ref={canvasRef} className="hidden" />
           
           {/* Stage Controls */}
           <div className="absolute bottom-6 left-6 right-6 z-50 flex justify-center gap-4 opacity-0 group-hover:opacity-100 transition-opacity">
               {capturedMedia && (
                   <Button variant="secondary" onClick={() => { setCapturedMedia(null); setGeneratedAvatar(null); }}>
                       Limpiar Escenario
                   </Button>
               )}
           </div>
        </div>
      </div>

      {/* Right Column: The Brain */}
      <div className="w-full lg:w-96 flex flex-col bg-slate-800/50 rounded-2xl border border-slate-700 shadow-xl backdrop-blur-sm">
         <div className="p-4 border-b border-slate-700 bg-gradient-to-r from-pink-600/20 to-purple-600/20 rounded-t-2xl flex items-center gap-3">
             <div className="w-3 h-3 bg-pink-500 rounded-full shadow-[0_0_10px_#ec4899]"></div>
             <span className="font-bold text-pink-400 text-sm tracking-wider">SANDRA YOUTUBER</span>
         </div>

         {/* Chat History */}
         <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
            {messages.map((msg, idx) => (
                <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-3 rounded-xl text-sm ${
                        msg.role === 'user' 
                        ? 'bg-pink-600 text-white rounded-br-none shadow-lg shadow-pink-900/20' 
                        : 'bg-slate-700 text-slate-200 rounded-bl-none'
                    }`}>
                        {msg.text}
                    </div>
                </div>
            ))}
            <div ref={messagesEndRef} />
         </div>

         {/* Input Area */}
         <div className="p-4 bg-slate-900/50 rounded-b-2xl border-t border-slate-700">
            <div className="flex items-center gap-2">
                <input 
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleCommand()}
                  placeholder="Dile a Sandra qué quieres crear..."
                  className="flex-1 bg-slate-900 border-slate-700 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-pink-500 outline-none"
                  disabled={isProcessing}
                />
                <Button 
                    variant="primary" 
                    className="p-2 rounded-lg bg-pink-600 hover:bg-pink-700"
                    onClick={handleCommand}
                    disabled={isProcessing || !inputText}
                >
                    {isProcessing ? <Sparkles className="animate-spin" size={18} /> : <Send size={18} />}
                </Button>
            </div>
            
            {/* Quick Actions */}
            <div className="mt-4 grid grid-cols-2 gap-2">
               <button onClick={() => { setInputText("Hacer una foto"); handleCommand(); }} className="text-xs bg-slate-800 hover:bg-slate-700 p-2 rounded text-slate-400 flex items-center justify-center gap-2 border border-slate-700 hover:border-pink-500/50 transition-colors"><Aperture size={14} className="text-pink-400"/> Foto</button>
               <button onClick={() => { setInputText("Grabar video de 5 segundos"); handleCommand(); }} className="text-xs bg-slate-800 hover:bg-slate-700 p-2 rounded text-slate-400 flex items-center justify-center gap-2 border border-slate-700 hover:border-pink-500/50 transition-colors"><Video size={14} className="text-pink-400"/> Video 5s</button>
               <button onClick={() => { setInputText("Crear mi avatar 3D animado"); handleCommand(); }} className="text-xs bg-slate-800 hover:bg-slate-700 p-2 rounded text-slate-400 flex items-center justify-center gap-2 border border-slate-700 hover:border-pink-500/50 transition-colors"><User size={14} className="text-pink-400"/> Avatar 3D</button>
               <button onClick={() => { setInputText("Generar un mundo de fantasía mágica"); handleCommand(); }} className="text-xs bg-slate-800 hover:bg-slate-700 p-2 rounded text-slate-400 flex items-center justify-center gap-2 border border-slate-700 hover:border-pink-500/50 transition-colors"><MonitorPlay size={14} className="text-pink-400"/> Crear Mundo</button>
            </div>
         </div>
      </div>
    </div>
  );
};