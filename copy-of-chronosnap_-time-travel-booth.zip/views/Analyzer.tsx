import React, { useState } from 'react';
import { ImageUploader } from '../components/ImageUploader';
import { CameraCapture } from '../components/CameraCapture';
import { Button } from '../components/Button';
import { analyzeImage } from '../services/geminiService';
import { ScanSearch, Copy, Check } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export const Analyzer: React.FC = () => {
  const [sourceImage, setSourceImage] = useState<File | null>(null);
  const [analysis, setAnalysis] = useState<string>("");
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleAnalyze = async () => {
    if (!sourceImage) return;
    setIsLoading(true);
    setAnalysis("");
    try {
      const prompt = "Analyze this image in detail. Describe the visual elements, the context, the style, and any notable objects or people. If it's a historical scene, identify the era.";
      const result = await analyzeImage(sourceImage, prompt);
      setAnalysis(result);
    } catch (error) {
      setAnalysis("Failed to analyze image. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(analysis);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {isCameraOpen && (
        <CameraCapture 
          onCapture={(file) => { setSourceImage(file); setIsCameraOpen(false); setAnalysis(""); }} 
          onClose={() => setIsCameraOpen(false)} 
        />
      )}

      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">
          Visual Intelligence
        </h2>
        <p className="text-slate-400">
          Upload any photo to get a detailed breakdown using Gemini 3 Pro Vision.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700 h-fit">
          <ImageUploader 
            currentImage={sourceImage}
            onFileSelect={(f) => { setSourceImage(f); setAnalysis(""); }}
            onCameraClick={() => setIsCameraOpen(true)}
          />
          
          {sourceImage && (
            <Button 
              className="w-full mt-6 py-3" 
              onClick={handleAnalyze}
              isLoading={isLoading}
              icon={<ScanSearch size={20} />}
            >
              {isLoading ? "Analyzing..." : "Analyze Image"}
            </Button>
          )}
        </div>

        <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700 min-h-[400px] flex flex-col">
          <div className="flex justify-between items-center mb-4 pb-4 border-b border-slate-700">
             <h3 className="font-semibold text-white">Analysis Result</h3>
             {analysis && (
               <button 
                 onClick={copyToClipboard}
                 className="flex items-center gap-2 text-xs text-slate-400 hover:text-white transition-colors"
               >
                 {copied ? <Check size={14} className="text-emerald-400"/> : <Copy size={14}/>}
                 {copied ? "Copied" : "Copy Text"}
               </button>
             )}
          </div>

          <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
            {isLoading ? (
              <div className="space-y-4 animate-pulse mt-4">
                <div className="h-4 bg-slate-700 rounded w-3/4"></div>
                <div className="h-4 bg-slate-700 rounded w-full"></div>
                <div className="h-4 bg-slate-700 rounded w-5/6"></div>
                <div className="h-4 bg-slate-700 rounded w-2/3"></div>
              </div>
            ) : analysis ? (
              <div className="prose prose-invert prose-sm max-w-none">
                <ReactMarkdown>{analysis}</ReactMarkdown>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-500 space-y-3">
                <ScanSearch size={48} strokeWidth={1} />
                <p>Select an image to reveal its secrets.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};