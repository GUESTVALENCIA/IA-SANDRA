import React, { useState } from 'react';
import { ImageUploader } from '../components/ImageUploader';
import { CameraCapture } from '../components/CameraCapture';
import { Button } from '../components/Button';
import { editImage } from '../services/geminiService';
import { Wand, ArrowRight } from 'lucide-react';

export const MagicEditor: React.FC = () => {
  const [sourceImage, setSourceImage] = useState<File | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleEdit = async () => {
    if (!sourceImage || !prompt) return;
    setIsLoading(true);
    try {
      const result = await editImage(sourceImage, prompt);
      setGeneratedImage(result);
    } catch (error) {
      alert("Failed to edit image.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {isCameraOpen && (
        <CameraCapture 
          onCapture={(file) => { setSourceImage(file); setIsCameraOpen(false); setGeneratedImage(null); }} 
          onClose={() => setIsCameraOpen(false)} 
        />
      )}

      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-purple-400">
          Magic Editor
        </h2>
        <p className="text-slate-400">
          Describe any change you want to make, and watch it happen.
        </p>
      </div>

      <div className="bg-slate-800/50 p-6 rounded-2xl border border-slate-700">
         <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            {/* Input */}
            <div className="space-y-4">
               <ImageUploader 
                 currentImage={sourceImage}
                 onFileSelect={(f) => { setSourceImage(f); setGeneratedImage(null); }}
                 onCameraClick={() => setIsCameraOpen(true)}
               />
            </div>

            {/* Output */}
            <div className="relative aspect-square md:aspect-auto md:h-full bg-slate-900 rounded-xl overflow-hidden flex items-center justify-center border border-slate-700/50">
               {generatedImage ? (
                 <img src={generatedImage} alt="Edited Result" className="w-full h-full object-contain" />
               ) : (
                 <div className="text-slate-500 text-center p-4">
                    <Wand size={40} className="mx-auto mb-2 opacity-50" />
                    <p>Edited image will appear here</p>
                 </div>
               )}
            </div>
         </div>

         {sourceImage && (
           <div className="mt-8 flex flex-col md:flex-row gap-4">
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Ex: 'Make it look like a pencil sketch' or 'Add a cat in the foreground'"
                className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-5 py-3 text-white focus:ring-2 focus:ring-pink-500 focus:border-transparent outline-none"
              />
              <Button 
                onClick={handleEdit}
                isLoading={isLoading}
                disabled={!prompt}
                className="md:w-48 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 border-none"
                icon={<ArrowRight size={20} />}
              >
                Execute
              </Button>
           </div>
         )}
      </div>
    </div>
  );
};